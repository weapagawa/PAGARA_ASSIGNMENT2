create function deleteorder(del text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

  begin
    if del NOTNULL then

      DELETE from breworder;
       loc_res = 'ok';

     else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
