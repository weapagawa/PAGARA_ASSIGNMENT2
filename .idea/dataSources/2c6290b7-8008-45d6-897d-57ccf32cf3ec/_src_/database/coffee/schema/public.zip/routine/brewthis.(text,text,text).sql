create function brewthis(bname text, bcoffee text, bquantity text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

  loc_name text;
  loc_coffee text;
  loc_quantity text;

  begin
    select into loc_name name, loc_coffee coffee, loc_quantity quantity from breworder;
     if bname NOTNULL then

       insert into breworder(name, coffee, quantity) values (bname, bcoffee, bquantity);
       loc_res = 'ok';
  else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
