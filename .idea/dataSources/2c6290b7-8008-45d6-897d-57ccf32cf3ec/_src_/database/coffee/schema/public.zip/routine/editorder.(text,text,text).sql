create function editorder(ebname text, ebcoffee text, ebquantity text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

    loc_ebname text;
    loc_ebcoffee text;
    loc_ebquantity text;
  begin
     select into loc_ebname name, loc_ebcoffee coffee, loc_ebquantity quantity from breworder;
     if loc_ebname NOTNULL then

       UPDATE breworder set name = ebname, coffee = ebcoffee,  quantity = ebquantity;
       loc_res = 'ok';

     else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
