create function displayorder(OUT text, OUT text, OUT text) returns SETOF record
LANGUAGE SQL
AS $$
--include ingredients + price here. learn how (triggers?)
  select name, coffee, quantity from breworder;
$$;
