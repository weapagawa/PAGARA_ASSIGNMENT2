create function displaymenu(OUT character varying, OUT character varying, OUT integer) returns SETOF record
LANGUAGE SQL
AS $$
select name, ingredients, price from menu;
$$;
